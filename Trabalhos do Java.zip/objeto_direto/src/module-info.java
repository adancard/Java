/**
 * 
 */
/**
 * @author Aluno
 *
 */
module objeto_direto {
}