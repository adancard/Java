package Calc_prin;

import java.util.Scanner;

import Calc.calc;

public class prin {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

	}

}
