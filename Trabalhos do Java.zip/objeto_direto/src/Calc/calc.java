package Calc;

public class calc {

	private int lado;
	
	public int getarea() {
		return (lado*lado);
	}

	public int getLado() {
		return lado;
	}

	public void setLado(int lado) {
		this.lado = lado;
	}
	
	
	
	
	
}
