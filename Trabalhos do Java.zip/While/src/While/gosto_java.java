package While;

public class gosto_java {

	public static void main(String[] args) {
		int cont = 0;
		
		while(true) {
			if(cont == 10) {
				break;
			}
			else {
				System.out.println("gosto de java");
				cont = cont + 1;
			}
		
		}
	 }

}


