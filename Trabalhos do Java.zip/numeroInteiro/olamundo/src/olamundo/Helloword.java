package olamundo;

public class Helloword {

	public static void main(String[] args) {
	 System.out.println("Hello Word");
	}
}