package ifelse;

import java.util.Scanner;

public class maior_que_10 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		int n1,n2;
      System.out.println("infome o primeiro numero: ");
      n1=entrada.nextInt();
      System.out.println("informe o segundo numero: ");
      n2=entrada.nextInt();
	
	}

}
