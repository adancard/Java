/**
 * 
 */
/**
 * @author Instrutor
 *
 */
module numeroInteiro {
}