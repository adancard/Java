package switchcase;

import java.util.Scanner;

public class letra {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		String letra;
		
		System.out.println("infome uma letra: ");
		letra = entrada.nextLine();
		
		switch(letra){
		case "a":
			System.out.println("sua letra eh vogal");
			break;
		case "e":
			System.out.println("sua letra eh vogal");
			break;
		case "i":
			System.out.println("sua letra eh vogal");
			break;
		case "o":
			System.out.println("sua letra eh vogal");
			break;
		case "u":
			System.out.println("sua letra eh vogal");
			break;
		case "q":
			System.out.println("sua letra eh consoante");
			break;
		case "w":
			System.out.println("sua letra eh consoante");
			break;
		case "r":
			System.out.println("sua letra eh consoante");
			break;
		case "t":
			System.out.println("sua letra eh consoante");
			break;
		case "y":
			System.out.println("sua letra eh consoante");
			break;
		case "p":
			System.out.println("sua letra eh consoante");
			break;
		case "s":
			System.out.println("sua letra eh consoante");
			break;
		case "d":
			System.out.println("sua letra eh consoante");
			break;
		case "f":
			System.out.println("sua letra eh consoante");
			break;
		case "g":
			System.out.println("sua letra eh consoante");
			break;
		case "h":
			System.out.println("sua letra eh consoante");
			break;
		case "j":
			System.out.println("sua letra eh consoante");
			break;
		case "k":
			System.out.println("sua letra eh consoante");
			break;
		case "l":
			System.out.println("sua letra eh consoante");
			break;
		case "z":
			System.out.println("sua letra eh consoante");
			break;
		case "x":
			System.out.println("sua letra eh consoante");
			break;
		case "c":
			System.out.println("sua letra eh consoante");
			break;
		case "v":
			System.out.println("sua letra eh consoante");
			break;
		case "b":
			System.out.println("sua letra eh consoante");
			break;
		case "n":
			System.out.println("sua letra eh consoante");
			break;
		case "m":
			System.out.println("sua letra eh consoante");
			break;
		case "ç":
			System.out.println("N sei :(");
			break;
			default:
			System.out.println("nao eh uma letra");
			break;
			
		}

	}

}