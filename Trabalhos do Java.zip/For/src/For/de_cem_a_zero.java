package For;

public class de_cem_a_zero {

	public static void main(String[] args) {
		int cont;
		for(cont = 100;cont >= 0;cont--) {
			System.out.println(cont);
		}
	}

}
