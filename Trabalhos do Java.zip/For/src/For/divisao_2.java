package For;

public class divisao_2 {

	public static void main(String[] args) {
	     int n;

	     for(n=1; n<=100; n++) {
	    	 if(n%2==0) {
	    		 System.out.println(n);	    		 
	 }    	 
    }
  }
 }