/**
 * 
 */
/**
 * @author Instrutor
 *
 */
module baseDotriangulo {
}