package metodo;

import java.util.Scanner;

public class Escola {
	
	public static void dicis(String dici3) {
	}


	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		
				


	}

}
