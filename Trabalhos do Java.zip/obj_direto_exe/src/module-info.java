/**
 * 
 */
/**
 * @author adan
 *
 */
module obj_direto_exe {
}